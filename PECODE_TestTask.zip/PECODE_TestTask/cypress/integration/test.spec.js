import PecodePage from "../support/PecodePage"

const baseURL = "https://www.pecodesoftware.com/qa-portal/greet.php"

const USERNAME = 'username'
const PASSWORD = 'password'

const homePage = new PecodePage()

const inputData = (field, data) => homePage.getField(field).type(data)

function login(username, password){
    inputData(USERNAME, username)
    inputData(PASSWORD, password)
    homePage.getLoginButton().click()
}


describe('Pecodesoftware Page', () => {

    beforeEach(() => {
        cy.visit(baseURL)
        cy.contains("AQA internship Login")
      })

    it('Check that all the elements are present on the page.', () => {
        homePage.getLogomini().should('be.visible')
        homePage.getField(USERNAME).should('be.visible')
        homePage.getField(PASSWORD).should('be.visible')
        homePage.getLoginButton().should('be.visible')
        cy.screenshot('initViewPecodePage')
    })
    
    it('Fill in the “Username” and “Password” input fields and click the “LogIn” button', () => {
        login('user', '1111')   
    })

    it('Verify that all the error messages appear', () => {
        homePage.getLoginButton().click()
        homePage.getUsernameErrorMessage().contains('Please enter username.').should('be.visible')
        homePage.getPasswordErrorMessage().contains('Please enter your password.').should('be.visible')
       
        login(' ', '1111')
        homePage.getUsernameErrorMessage().contains('Please enter username.').should('be.visible')
        homePage.getPasswordErrorMessage().should('be.empty')
       
        login('user', ' ')
        homePage.getUsernameErrorMessage().should('be.empty')
        homePage.getPasswordErrorMessage().contains('Please enter your password.').should('be.visible')

        //It's also verify that will fail because of unsuccessful login
        login('user', '1111')
        homePage.getUsernameErrorMessage().contains('No account found with that username.').should('be.visible')
        homePage.getPasswordErrorMessage().should('be.empty')
    })

    // if add .skip  or change 'not.be.visible' to 'be.visible' - all tests will pass
    it.skip('Verify creation screenshot after fail in test', () => {
        homePage.getLogomini().should('not.be.visible')
    })

})
