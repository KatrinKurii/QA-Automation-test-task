class PecodePage {
    getLogomini() {
        return cy.get('#logomini')
    }
    getField(field) {
        return cy.get(`input[name="${field}"]`)
    }
    getLoginButton() {
        return cy.get('[type="submit"]')
    }
    getUsernameErrorMessage() {
        return cy.get('.help-block').eq(0)
    }
    getPasswordErrorMessage() {
        return cy.get('.help-block').eq(1)
    }
    }
    export default PecodePage
    