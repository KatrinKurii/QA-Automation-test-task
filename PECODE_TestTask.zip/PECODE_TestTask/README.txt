For run test in a docker container.:
    npm run run-test-in-container


A mochawesome report file:
        PECODE_TestTask/cypress/reports/
        
Screenshots for failing the test:  
        PECODE_TestTask/cypress/screenshots/

Video recording for all the tests:
        PECODE_TestTask/cypress/videos/
